from base import *


DATABASES = {
    'default': {
        'NAME': 'liucheng',
        'ENGINE': 'django.db.backends.mysql',
        'USER': 'root',
        'PASSWORD': 'root',
        'HOST': '127.0.0.1', 
        'PORT': '3306',        
      },
    }