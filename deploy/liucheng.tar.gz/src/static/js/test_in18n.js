
alert(gettext('this is to be translated'))
gettext('klf')

ex.template('<div class="img-crop">',{yy:gettext('yy')})


gettext('mm')