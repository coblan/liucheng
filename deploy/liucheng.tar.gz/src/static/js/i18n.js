/**
 * Created by coblan on 2017/3/12.
 */
function gettext(word){
    var word =  lan[word] || word
    return word
}

lan={
    From:'从',
    To:'到',
    submit:'提交',
    search:'查询',
}